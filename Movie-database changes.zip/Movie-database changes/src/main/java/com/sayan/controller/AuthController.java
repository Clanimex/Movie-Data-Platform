package com.sayan.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sayan.UserService.AuthService;
import com.sayan.dtos.JwtAuthResponse;
import com.sayan.dtos.LoginDto;

/**
 * Controller class for handling authentication-related requests. This class
 * provides endpoints for user login.
 */

@RestController
@RequestMapping("/api/auth")
public class AuthController {

	private AuthService authService;

	/**
	 * Constructor for AuthController.
	 *
	 * @param authService the authentication service to be used
	 */

	public AuthController(AuthService authService) {
		super();
		this.authService = authService;
	}
	
	/**
     * Endpoint for user login.
     *
     * @param loginDto the login credentials
     * @return a ResponseEntity containing the JWT authentication response
     */
	
	@PostMapping("/login")
	public ResponseEntity<JwtAuthResponse> login(@RequestBody LoginDto loginDto) {
		String result = authService.login(loginDto);
		JwtAuthResponse response = new JwtAuthResponse();
		response.setAccessToken(result);
		return ResponseEntity.ok(response);
	}
}