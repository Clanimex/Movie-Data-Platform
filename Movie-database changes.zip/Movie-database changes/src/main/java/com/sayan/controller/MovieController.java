package com.sayan.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sayan.Entities.Movies;
import com.sayan.service.MovieService;

/**
 * Controller class for handling movie-related requests. This class provides
 * endpoints for CRUD operations on movies.
 */

@RequestMapping("/movies")
@RestController
public class MovieController {
	private MovieService movieService;

	/**
	 * Constructor for MovieController.
	 *
	 * @param movieService the movie service to be used
	 */

	public MovieController(MovieService movieService) {
		super();
		this.movieService = movieService;
	}


	/**
	 * Endpoint to get all movies.
	 *
	 * @return a ResponseEntity containing the list of movies
	 */

	@GetMapping
	public ResponseEntity<List<Movies>> getAll() {
		List<Movies> movies = movieService.getAllMovie();
		return ResponseEntity.ok(movies);
	}


	/**
	 * Endpoint to get a movie by its ID.
	 *
	 * @param id the ID of the movie
	 * @return a ResponseEntity containing the movie if found, or a 404 Not Found
	 *         status
	 */

	@GetMapping("/{id}")
	public ResponseEntity<Movies> getMovieById(@PathVariable int id) {
		Movies movie = movieService.getById(id);
		return ResponseEntity.ok(movie);
	}
	
	/**
     * Endpoint to add a new movie.
     *
     * @param movies the movie to be added
     * @return a ResponseEntity containing the added movie and a 201 Created status
     */
	
	@PostMapping
	public ResponseEntity<Movies> addMovies(@RequestBody Movies movies) {
		var mov = movieService.addMovie(movies);
		return new ResponseEntity<>(mov,HttpStatus.CREATED);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Movies> updateMovie(@PathVariable int id, @RequestBody Movies movies) {
		Movies updatedmovie = movieService.updateMovie(id, movies);
		return new ResponseEntity<>(updatedmovie, HttpStatus.OK);
	}
	
	/**
     * Endpoint to delete a movie by its ID.
     *
     * @param id the ID of the movie to be deleted
     * @return a ResponseEntity containing a message and a 204 No Content status
     */
//	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteMovie(@PathVariable int id) {
		var mov3 = movieService.deleteMovie(id);

		return new ResponseEntity<String>(mov3, HttpStatus.NO_CONTENT);
	}
}
