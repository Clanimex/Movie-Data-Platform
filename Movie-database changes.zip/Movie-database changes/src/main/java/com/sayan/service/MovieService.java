package com.sayan.service;

import java.util.List;

/**
 * Service interface for managing movies.
 * This interface provides methods for CRUD operations on movies.
 */

import com.sayan.Entities.Movies;

/**
 * Retrieves all movies.
 *
 * @return a list of all movies
 */

public interface MovieService {
	List<Movies> getAllMovie();

	Movies getById(int id);

	Movies addMovie(Movies movies);
	
	Movies updateMovie(int id,Movies movies);

	String deleteMovie(int id);
}