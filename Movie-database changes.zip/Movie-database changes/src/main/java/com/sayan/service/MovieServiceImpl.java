package com.sayan.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.sayan.Entities.Movies;
import com.sayan.exceptions.MovieNotFoundException;
import com.sayan.repository.MovieRepository;

/**
 * Implementation of the MovieService interface. This class provides methods for
 * CRUD operations on movies.
 */

@Service
public class MovieServiceImpl implements MovieService {

	private MovieRepository movieRepository;

	/**
	 * Constructor for MovieServiceImpl.
	 *
	 * @param movieRepository the movie repository to be used
	 */
	public MovieServiceImpl(MovieRepository movieRepository) {
		super();
		this.movieRepository = movieRepository;
	}

	/**
	 * Retrieves all movies.
	 *
	 * @return a list of all movies
	 */
	@Override
	public List<Movies> getAllMovie() {
		// TODO Auto-generated method stub
		return movieRepository.findAll();
	}

	/**
	 * Retrieves a movie by its ID.
	 *
	 * @param id the ID of the movie
	 * @return the movie with the specified ID
	 * @throws MovieNotFoundException if the movie with the specified ID is not
	 *                                found
	 */
	@Override
	public Movies getById(int id) {
		// TODO Auto-generated method stub
		return movieRepository.findById(id)
				.orElseThrow(() -> new MovieNotFoundException("Exception with id " + id + " does not exists"));
	}

	/**
	 * Adds a new movie.
	 *
	 * @param movies the movie to be added
	 * @return the added movie
	 */
	@Override
	public Movies addMovie(Movies movies) {
		// TODO Auto-generated method stub
		return movieRepository.save(movies);
	}
	
	
	@Override
	public Movies updateMovie(int id, Movies movies) {
		// TODO Auto-generated method stub
 
		Optional<Movies> byId = movieRepository.findById(id);
		if (!byId.isPresent()) {
			throw new MovieNotFoundException("Movie with id " + id + " does not exist");
		}
 
		Movies mov = byId.get();
		if (movies.getTitle() != null) {
			mov.setTitle(movies.getTitle());
 
		}
		if (movies.getDirector() != null) {
			mov.setDirector(movies.getDirector());
		}
		if (movies.getRelease_year() != 0) {
			mov.setRelease_year(movies.getRelease_year());
		}
		if (movies.getGenre() != null) {
			mov.setGenre(movies.getGenre());
		}
		if (movies.getRating() != 0) {
			mov.setRating(movies.getRating());
		}
		return movieRepository.save(mov);
	}

	/**
	 * Deletes a movie by its ID.
	 *
	 * @param id the ID of the movie to be deleted
	 * @return a message indicating the result of the deletion
	 * @throws MovieNotFoundException if the movie with the specified ID is not
	 *                                found
	 */
	@Override
	public String deleteMovie(int id) {
		// TODO Auto-generated method stub
		Optional<Movies> movopt = movieRepository.findById(id);
		if (movopt.isEmpty()) {
			throw new MovieNotFoundException("Exception with Id " + id + " does not exist");
		}
		movieRepository.deleteById(id);
		return "movie with Id " + id + " deleted successfully";
	}

}
