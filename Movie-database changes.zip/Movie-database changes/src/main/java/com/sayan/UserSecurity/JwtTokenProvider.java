package com.sayan.UserSecurity;

import java.security.Key;
import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.sayan.exceptions.DemoAppException;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtTokenProvider {

	@Value("${app.jwt.secret}") // this syntax is used to take the data from the application property file
	public String jwtSecret;
	@Value("${app.jwt.expiry-mills}")
	private long expiryMills;

	
	public String generateToken(Authentication authentication) {
		String username = authentication.getName();
		Date currentDate = new Date();
		Date expiryDate = new Date(currentDate.getTime() + expiryMills);

		String token = Jwts.builder().subject(username).issuedAt(new Date()).expiration(expiryDate).signWith(key())
				.compact();

		return token;
	}


	private Key key() {
		return Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
	}

	public String getUsernameFromToken(String token) {
		String username = Jwts.parser().verifyWith((SecretKey) key()).build().parseSignedClaims(token).getPayload()
				.getSubject();
		return username;
	}


	public boolean validateToken(String token) {
		try {
			Jwts.parser().verifyWith((SecretKey) key()).build().parse(token);
			return true;
		} catch (MalformedJwtException ex) {
			throw new DemoAppException(HttpStatus.BAD_REQUEST, "Invalid token");
		} catch (ExpiredJwtException ex) {
			throw new DemoAppException(HttpStatus.BAD_REQUEST, "Token is expired");
		}

		catch (UnsupportedJwtException ex) {
			throw new DemoAppException(HttpStatus.BAD_REQUEST, "Unsupported Exception");
		}

		catch (IllegalArgumentException ex) {
			throw new DemoAppException(HttpStatus.BAD_REQUEST, "Token claims is empty");
		}

	}
}