package com.sayan.UserSecurity;

import java.io.IOException;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Component class that handles unauthorized access attempts. This class
 * implements AuthenticationEntryPoint to send an unauthorized error response.
 */

@Component
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {

	/**
	 * Commences an authentication scheme. This method is called when an
	 * authentication exception is thrown.
	 *
	 * @param request       the HttpServletRequest
	 * @param response      the HttpServletResponse
	 * @param authException the authentication exception
	 * @throws IOException      if an input or output error occurs
	 * @throws ServletException if a servlet error occurs
	 */
	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException, ServletException {
		// TODO Auto-generated method stub
		response.sendError(HttpServletResponse.SC_UNAUTHORIZED, authException.getMessage());

	}

}
