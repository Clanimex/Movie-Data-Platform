package com.sayan.UserSecurity;

import java.util.Collections;
import java.util.Set;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.sayan.UserEntities.User;
import com.sayan.UserRepository.UserRepository;

import lombok.RequiredArgsConstructor;

/**
 * Service class for loading user-specific data. This class implements
 * UserDetailsService to provide user details for authentication.
 */

@Service
@RequiredArgsConstructor
public class MovieUserDetailsService implements UserDetailsService {
	private final UserRepository userRepository;

	/**
	 * Loads the user by their username or email.
	 *
	 * @param username the username or email of the user
	 * @return UserDetails containing user information
	 * @throws UsernameNotFoundException if the user is not found
	 */
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepository.findByUsernameOrEmail(username, username)
				.orElseThrow(() -> new UsernameNotFoundException("User with name or email " + username + " not found"));

		SimpleGrantedAuthority authority = new SimpleGrantedAuthority(user.getRoles());

		Set<SimpleGrantedAuthority> authorities = Collections.singleton(authority);

		UserDetails userDetails = new org.springframework.security.core.userdetails.User(user.getUsername(),
				user.getPassword(), authorities);
		return userDetails;
	}
}
