package com.sayan.exceptions;

/**
 * Custom exception class for handling cases where a movie is not found. This
 * class extends RuntimeException and provides constructors for exception
 * messages.
 */

public class MovieNotFoundException extends RuntimeException {

	/**
	 * Default constructor for MovieNotFoundException.
	 */
	public MovieNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor for MovieNotFoundException with a custom message.
	 *
	 * @param message the detail message for the exception
	 */
	public MovieNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
