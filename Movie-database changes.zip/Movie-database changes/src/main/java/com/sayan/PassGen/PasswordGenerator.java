package com.sayan.PassGen;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Utility class for generating encrypted passwords. This class uses
 * BCryptPasswordEncoder to encode passwords.
 */

public class PasswordGenerator {
	
	/**
     * The main method which serves as the entry point for the password generation utility.
     *
     */
	public static void main(String args[]) {
		PasswordEncoder encoder = new BCryptPasswordEncoder();
		System.out.println(encoder.encode("Sayan123"));
//		System.out.println(encoder.encode("Asim@123"));
	}

}
