package com.sayan.UserRepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sayan.UserEntities.User;

/**
 * Repository interface for accessing user data. This interface extends
 * JpaRepository to provide CRUD operations for the User entity.
 */
public interface UserRepository extends JpaRepository<User, Integer> {

	/**
	 * Finds a user by their username.
	 *
	 * @param username the username of the user
	 * @return an Optional containing the user if found, or empty if not found
	 */
	Optional<User> findByUsername(String username);
	
	/**
     * Finds a user by their email.
     *
     * @param email the email of the user
     * @return an Optional containing the user if found, or empty if not found
     */
	Optional<User> findByEmail(String email);
	
	/**
     * Finds a user by their username or email.
     *
     * @param username the username of the user
     * @param email the email of the user
     * @return an Optional containing the user if found, or empty if not found
     */
	Optional<User> findByUsernameOrEmail(String username, String email);
}
