package com.sayan.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Data Transfer Object (DTO) for login requests. This class contains the
 * username or email and password for authentication.
 */

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class LoginDto {
	
	/**
     * The username or email of the user.
     */

	private String usernameOrEmail;
	
	/**
     * The password of the user.
     */
	
	private String password;

}
