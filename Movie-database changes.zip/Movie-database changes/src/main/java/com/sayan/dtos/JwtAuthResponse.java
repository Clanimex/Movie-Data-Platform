package com.sayan.dtos;

import lombok.Getter;
import lombok.Setter;

/**
 * Data Transfer Object (DTO) for JWT authentication response. This class
 * contains the access token and token type for the response.
 */

public class JwtAuthResponse {

	/**
	 * The JWT access token.
	 */

	@Getter
	@Setter
	private String accessToken;

	/**
	 * The type of the token, default is "Bearer".
	 */

	@Getter
	private String tokenType = "Bearer";

}
