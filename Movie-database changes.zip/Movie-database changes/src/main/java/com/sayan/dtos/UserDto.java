package com.sayan.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object (DTO) for user information. This class contains the
 * user's name, username, email, and password.
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserDto {
	
	private String name;
	private String username;
	private String email;
	private String password;

}
