package com.sayan.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.sayan.UserSecurity.JwtTokenProvider;
import com.sayan.dtos.LoginDto;

/**
 * Service implementation for handling user authentication.
 */
@Service
public class AuthServiceImpl implements AuthService {
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	
	/**
     * Authenticates the user and generates a JWT token.
     *
     * @param loginDto the login data transfer object containing username/email and password
     * @return the generated JWT token
     */

	@Override
	public String login(LoginDto loginDto) {
		// TODO Auto-generated method stub
		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
				loginDto.getUsernameOrEmail(), loginDto.getPassword());
		// Authenticate the user
		Authentication authentication = authenticationManager.authenticate(token);
		
		// Set the authentication in the security context
		SecurityContextHolder.getContext().setAuthentication(authentication);
		
		// Generate a JWT token for the authenticated user
		String jwt = jwtTokenProvider.generateToken(authentication);
		
		return jwt;
	}

}
