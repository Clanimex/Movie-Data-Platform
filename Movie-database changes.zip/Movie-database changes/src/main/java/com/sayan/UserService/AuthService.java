package com.sayan.UserService;

import com.sayan.dtos.LoginDto;

/**
 * Service interface for authentication operations. This interface provides a
 * method for user login.
 */
public interface AuthService {

	/**
	 * Authenticates a user based on login credentials.
	 *
	 * @param loginDto the login credentials
	 * @return a JWT token if authentication is successful
	 */

	String login(LoginDto loginDto);

}
