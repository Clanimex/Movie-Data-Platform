package com.sayan.Entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Entity class representing a movie. This class maps to the "movie_data" table
 * in the database.
 */

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "movie_data")
public class Movies {

	/**
	 * The unique identifier for the movie.
	 */

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "movie_id")
	private int id;

	@Column(name = "movie_name")
	private String title;

	@Column(name = "director_name")
	private String director;
	
	@Column(name = "year_of_release")
	private int release_year;

	@Column(name = "movie_genre")
	private String genre;

	@Column(name = "movie_ratings")
	private double rating;
}
