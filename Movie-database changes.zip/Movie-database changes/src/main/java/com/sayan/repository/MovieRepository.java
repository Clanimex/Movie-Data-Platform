package com.sayan.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sayan.Entities.Movies;

/**
 * Repository interface for accessing movie data. This interface extends
 * JpaRepository to provide CRUD operations for the Movies entity.
 */

public interface MovieRepository extends JpaRepository<Movies, Integer> {

}
