package com.sayan.controller;
 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.sayan.Entities.Movies;
import com.sayan.service.MovieService;


/**
 * Test class for MovieController.
 */
@SpringBootTest
@AutoConfigureMockMvc
public class MovieControllerTest {
 
    @Mock
    private MovieService movieService;
    
    @InjectMocks
    private MovieController movieController;


    private Movies movies;
 
    /**
     * Sets up the test data before each test.
     */

    @BeforeEach
    void setUp() {
        movies = new Movies();
        movies.setId(1);
        movies.setTitle("kick");
        movies.setDirector("rohit shetty");
        movies.setRelease_year(2020);
        movies.setGenre("action");
        movies.setRating(4.3);
    }
    
    /**
     * Tests the getAll method of MovieController.
     *
     * @throws Exception if an error occurs during the test
     */
    @Test
    void testGetAll() throws Exception {
    	List<Movies> movies = Arrays.asList(
                new Movies(1, "kick", "k.k banerjee", 2020, "Fiction", 29.99),
                new Movies(2, "Dabang", "A.p sharma", 2021, "Non-Fiction", 39.99)
            );

            when(movieService.getAllMovie()).thenReturn(movies);
            ResponseEntity<List<Movies>> response = movieController.getAll();
            System.out.println(response);
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(movies, response.getBody());
    }
    
    /**
     * Tests the addMovie method of MovieController.
     *
     * @throws Exception if an error occurs during the test
     */
    @Test
    void testAddMovie() throws Exception {
    	 Movies movie = new Movies(1, "kick", "k.k sharma", 2022, "Science", 49.99);
         when(movieService.addMovie(movie)).thenReturn(movie);
 
         ResponseEntity<Movies> response = movieController.addMovies(movie);
         assertEquals(HttpStatus.CREATED, response.getStatusCode());
         assertEquals(movie, response.getBody());
    }
    
    /**
     * Tests the getMovieById method of MovieController.
     *
     * @throws Exception if an error occurs during the test
     */
    @Test
    void testGetMovieById() throws Exception {
    	Movies movie = new Movies(1, "kick", "p.l sharma", 2020, "Fiction", 29.99);
         when(movieService.getById(1)).thenReturn(movie);
 
         ResponseEntity<Movies> response = movieController.getMovieById(1);
         assertEquals(HttpStatus.OK, response.getStatusCode());
         assertEquals(movie, response.getBody());
    }
    
	@Test
	void testUpdateMovie() throws Exception {
		Movies movie = new Movies(1, "kick", "k.k singh", 2023, "History", 29.99);
		when(movieService.updateMovie(1, movie)).thenReturn(movie);
 
		ResponseEntity<Movies> response = movieController.updateMovie(1, movie);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(movie, response.getBody());
	}
  
    /**
     * Tests the deleteMovie method of MovieController.
     *
     * @throws Exception if an error occurs during the test
     */
    @Test
    void testDelete() throws Exception {
    	 when(movieService.deleteMovie(1)).thenReturn("movie deleted");
 
         ResponseEntity<String> response = movieController.deleteMovie(1);
         assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
         assertEquals("movie deleted", response.getBody());
    }
 
   
}