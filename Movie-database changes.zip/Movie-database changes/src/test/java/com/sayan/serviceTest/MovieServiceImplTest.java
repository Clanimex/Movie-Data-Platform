package com.sayan.serviceTest;
 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.sayan.Entities.Movies;
import com.sayan.repository.MovieRepository;
import com.sayan.service.MovieService;
import com.sayan.service.MovieServiceImpl;

/**
 * Test class for MovieServiceImpl.
 */
class MovieServiceImplTest {
 
	MovieRepository mockMovieRepository = mock(MovieRepository.class);
	MovieService movieService = new MovieServiceImpl(mockMovieRepository);
    private Movies movies;
    
    /**
     * Sets up the test data before each test.
     */
	 @BeforeEach
	    void setUp() {
	        movies = new Movies(1, "kick", "rohit shetty", 2020, "action", 4.3);
	    }
	 
	 /**
	     * Tests the getAllMovies method of MovieServiceImpl.
	     */
	@Test
//	@Disabled
	void testGetAllMovies() {
 
		when(mockMovieRepository.findAll())
				.thenReturn(List.of(new Movies(1, "kick", "rohit shetty", 2020, "action", 4.3),
						new Movies(2, "Dabang", "karan kapoor", 2018, "action", 3.3)));
		var movies = movieService.getAllMovie();
		assertEquals(2, movies.size());
	}
	
	/**
     * Tests the getById method of MovieServiceImpl.
     */
	@Test
	void testGetById() {
		when(mockMovieRepository.findById(anyInt()))
		.thenReturn(Optional.of(new Movies(1, "singham", "rohit shetty", 2020, "action", 4.3)));
		Movies movie= movieService.getById(1);
		assertEquals("singham",movie.getTitle());
	}
	
	/**
     * Tests the addMovie method of MovieServiceImpl.
     */
	@Test
	void testAddMovie() {
	  Movies newMovie=new Movies(1, "kick", "rohit shetty", 2020, "action", 4.3);
	  when(mockMovieRepository.save(newMovie))
	  .thenReturn(newMovie);
	  Movies movies= movieService.addMovie(newMovie);
	  assertEquals(newMovie.getId(),movies.getId());
	  assertEquals(newMovie.getDirector(),movies.getDirector());
	  assertEquals(newMovie.getGenre(),movies.getGenre());
	  assertEquals(newMovie.getRating(),movies.getRating());
	  assertEquals(newMovie.getRelease_year(),movies.getRelease_year());
	}
 
	@Test
	void testUpdateMovie() {
		 when(mockMovieRepository.findById(1)).thenReturn(Optional.of(movies));
	        Movies updatedBook = new Movies(1, "Effective Java 2nd Edition", "Joshua Bloch", 2008, "Programming", 50.00);
	        when(mockMovieRepository.save(any(Movies.class))).thenReturn(updatedBook);
	        Movies result = movieService.updateMovie(1, updatedBook);
	        assertNotNull(result);
	        assertEquals(updatedBook.getTitle(), result.getTitle());
	}
 
 
	/**
     * Tests the deleteMovie method of MovieServiceImpl.
     */
	@Test
	void testDeleteMovie() {
		  when(mockMovieRepository.findById(1)).thenReturn(Optional.of(movies));
	        doNothing().when(mockMovieRepository).deleteById(1);
	        String result = movieService.deleteMovie(1);
	        assertEquals("movie with Id 1 deleted successfully", result);
	}
 
}